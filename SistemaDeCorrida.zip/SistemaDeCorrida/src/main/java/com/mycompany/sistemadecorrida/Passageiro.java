/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sistemadecorrida;

/**
 *
 * @author Khauan
 */
public class Passageiro extends Usuario implements SolicitacaoCorrida, Pagamento{

    public Passageiro(String nome, int id) {
        super(nome, id);
    }
    
    public void solicitarCorrida(){
        System.out.println(nome + " solicitou uma corrida");
    }
    
    @Override
    public void mostrarInformacoes() {
        System.out.println("Passageiro: " + nome + " ID: " + id);
    }

    @Override
    public void realizarPagamento() {
        System.out.println(nome + " realizou o pagamento da corrida");

    }
    
}
