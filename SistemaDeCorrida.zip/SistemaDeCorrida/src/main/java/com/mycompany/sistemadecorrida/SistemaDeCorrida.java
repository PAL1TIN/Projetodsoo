/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.sistemadecorrida;

/**
 *
 * @author Khauan
 */
public class SistemaDeCorrida {

    public static void main(String[] args) {
    
        Passageiro passageiro = new Passageiro("Carlos", 012);
        Motorista motorista = new Motorista("Khauan", 720);
        
        Corrida corrida1 = new Corrida(passageiro, motorista, "Av. Portugueses", "Estrada da Mata");
        
        corrida1.iniciarCorrida();
        corrida1.finalizarCorrida();
    }
}
