/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sistemadecorrida;

/**
 *
 * @author Khauan
 */
public class Corrida {
    private Passageiro passageiro;
    private Motorista motorista;
    private String origem;
    private String destino;

    public Corrida(Passageiro passageiro, Motorista motorista, String origem, String destino) {
        this.passageiro = passageiro;
        this.motorista = motorista;
        this.origem = origem;
        this.destino = destino;
    }
    
    public void iniciarCorrida(){
        passageiro.solicitarCorrida();
        motorista.definirRota(origem, destino);
        System.out.println("A corrida esta partindo para " + destino);
    }
    
    public void finalizarCorrida(){
        passageiro.realizarPagamento();
        motorista.realizarPagamento();
        System.out.println("A corrida foi finalizada");
    }
    
}
